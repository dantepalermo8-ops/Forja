# FORJA — Entrenamiento

Aplicación web de entrenamiento en un único archivo HTML.

## Publicarla en GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube `index.html` a la raíz del repositorio.
3. Ve a **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`.
6. Guarda y espera a que GitHub Pages publique la aplicación.

La aplicación guarda los datos en `localStorage` cuando se ejecuta como una web independiente, por lo que funciona directamente en GitHub Pages sin servidor.
